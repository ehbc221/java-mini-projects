package fr.julien.chat.util;


public class FichierConversation {

	public static String DOSSIER_PARTAGE = "D:\\Dossier_partage";
	public static String NOM_FICHIER = "conversation.html";
}
