package fr.julien.chat.metier;

public interface ISerialisableHTML {
	
	public String toHTML();

}
