Chat pour un r�seau local-------------------------
Url     : http://codes-sources.commentcamarche.net/source/54135-chat-pour-un-reseau-localAuteur  : cs_Julien39Date    : 05/08/2013
Licence :
=========

Ce document intitul� � Chat pour un r�seau local � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Cette source permet de cr&eacute;er un chat sur un r&eacute;seau local.
<br />

<br />Pour cela, il suffit de cr&eacute;er un dossier partag&eacute; et de donn
er le path de ce dossier dans la variable DOSSIER_PARTAGE de la classe FichierCo
nversation.
<br />
<br />Seules les couleurs rouge, noir, bleu et vert peuvent
 &ecirc;tre choisies.
